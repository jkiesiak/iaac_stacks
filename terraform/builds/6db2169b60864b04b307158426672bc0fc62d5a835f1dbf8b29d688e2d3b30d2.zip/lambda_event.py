import json
from typing import Any

import boto3

s3 = boto3.client("s3")
rds_data = boto3.client("rds-data")
lambda_client = boto3.client("lambda")

db_cluster_arn = "your-db-cluster-arn"
db_secret_arn = "your-db-secret-arn"
db_name = "your-db-name"


def lambda_backup_to_s3(event, context, destination_bucket_name: str, file: Any):
    rows = file.split("\n")
    s3.put_object(Bucket=destination_bucket_name, Body=rows)
    return {
        "statusCode": 200,
        "body": json.dumps("Data inserted into s3"),
    }


def lambda_insert_into_database(event, context, file: Any):
# TODO: refactor function
    with rds_data.begin_transaction(
        resourceArn=db_cluster_arn, secretArn=db_secret_arn, database=db_name
    ) as transaction:
        for row in file:
            values = row.split(",")
            sql = "INSERT INTO your_table_name (column1, column2) VALUES (:val1, :val2)"
            params = [
                {"name": "val1", "value": {"stringValue": values[0]}},
                {"name": "val2", "value": {"stringValue": values[1]}},
            ]
            transaction.execute_statement(sql=sql, parameters=params)


if __name__ == "__main__":
    file_name = "customers.json"
    with open(file_name, "r") as file:
        file = file.read()

    lambda_backup_to_s3("test_bucket_name", file)
